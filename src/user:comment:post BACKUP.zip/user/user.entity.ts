import {
  Column,
  Entity,
 OneToMany,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { Post } from '../post/post.entity';
import { Comment } from '../comment/comment.entity';
import { Field, ObjectType } from '@nestjs/graphql';

enum RoleEnum {
  Admin = 'Admin',
  Author = 'Author',
}

@Entity()
@ObjectType()
export class User {
  @PrimaryGeneratedColumn('uuid')
  @Field()
  id: string;

  @Column()
  @Field()
  name: string;

  @Column()
  @Field()
  email: string;

  @Column()
  @Field()
  password: string;

  @Column({
    type: 'enum',
    enum: RoleEnum,
    default: RoleEnum.Author,
  })
  @Field()
  role: RoleEnum;

  @OneToMany((type) => Post, post => post.user)
  @Field(type=>Post)
  posts: Post[];

  @OneToMany((type) => Comment, comment => comment.author)
  @Field(type=>Comment)
  comments: Comment[];
}
