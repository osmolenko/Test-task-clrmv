import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { User } from './user.entity';
import { Repository } from 'typeorm';
import { CreateUserDto } from './dto/createuser.dto';

@Injectable()
export class UserService {
  constructor (@InjectRepository(User) private readonly userRepository: Repository<User>) {}
  async createUser (data: CreateUserDto): Promise<User> {
    const user = new User()
    user.name=data.name
    user.email=data.email
    user.role=data.role
    user.password=data.password

    await this.userRepository.save(user)

    return user
  }
}
